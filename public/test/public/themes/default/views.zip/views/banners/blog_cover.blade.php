<section class="brand-banner-img-wrapper">
	<div class="banner banner-o-hid" style="background-color: #333;">
		<div class="banner-caption">
			<h5 class="banner-title"><a href="{{ route('blog') }}">{!! trans('app.blog_page_header', ['platform' => get_platform_title()]) !!}</a></h5>
		</div>
	</div>
</section>