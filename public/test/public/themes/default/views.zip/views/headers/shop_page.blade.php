<!-- BANNER IMAGE -->
<section class="store-banner-img-wrapper">
  <div class="banner banner-o-hid" style="background-image:url(img/featured/22.jpg);">
      <div class="banner-caption">
          <h5 class="banner-title">The Demo Shop</h5>
          <p class="banner-desc">Low Price for Great Perfomance</p>
      </div>
  </div>
</section>
