<section>
    <div class="container">
        <header class="page-header">
            <div class="row">
                <div class="col-md-12">
                    <ol class="breadcrumb nav-breadcrumb">
                      @include('headers.lists.account')
                      @include('headers.lists.orders')
                      <li class="active">@lang('theme.order_detail')</li>
                    </ol>
                </div>
            </div>
        </header>
    </div>
</section>