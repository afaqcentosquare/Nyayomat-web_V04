@extends('layouts.main')

@section('content')

<nav class="navbar navbar-default navbar-static-top" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
				data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav" style="margin-top: 6px;">
				<li style="margin-top:5px;"><strong>Shop by category</strong></li>
				@foreach($categories as $item)
					<li>
						<a href="{{ route('category.browse', $item['slug']) }}">{{ $item['name'] }}</a>
					</li>
				@endforeach
			</ul>
		</div>
	</div>
</nav>

<section style="margin-top:30px;margin-bottom: 30px; padding:10px;">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-sx-12 col-md-12">

				<ul>

				</ul>

			</div>

			<!-- <div class="col-sm-12">
            		{!! Form::open(['route' => 'inCategoriesSearch', 'method' => 'GET', 'id' => 'search-categories-form', 'class' => 'navbar-left navbar-form navbar-search', 'role' => 'search']) !!}
				      <select name="in" class="search-category-select ">
				        <option value="all_categories">{{ trans('theme.all_categories') }}</option>
				        @foreach($search_category_list as $slug => $category)
				          <option value="{{ $slug }}"
				            @if(Request::has('in'))
				             {{ Request::get('in') == $slug ? ' selected' : '' }}
				            @endif
				          >{{ $category }}</option>
				        @endforeach
				      </select>
				      <div class="form-group">
				        {!! Form::text('search', null, ['class' => 'form-control', 'placeholder' => trans('theme.main_searchbox_placeholder')]) !!}
				      </div>
				      <a class="fa fa-search navbar-search-submit" onclick="document.getElementById('search-categories-form').submit()"></a>
				    {!! Form::close() !!}
            	</div> -->

		</div>
	</div>
</section>

<!--<section class="category-banner-img-wrapper" style="margin-bottom: 10px;">-->
	@include('banners.best_deals')
	<!--<div class="container">-->
	<!--	<div class="row">-->
	<!--		<div class="col-sm-12">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;height:200px;background-size: cover; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/add.jpg );">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--	</div>-->
	<!--</div>-->
<!--</section>-->

<section class="category-banner-img-wrapper" style="margin-bottom: 10px;">
    @include('sliders.browsing_items')
	<!--<div class="container">-->
	<!--	<div class="row">-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->
	<!--		<div class="col-sm-2" style="margin-top:10px;">-->
	<!--			<div class="banner banner-o-hid"-->
	<!--				style="background-color: #333;background-size: contain; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/deal.jpg );width:100%;height:150px;">-->
	<!--			</div>-->
	<!--		</div>-->

	<!--	</div>-->
	<!--</div>-->
</section>


@endsection
