<div class="modal auth-modal fade" id="loginModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content flat">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
        <span class="modal-title">{{ trans('theme.account_login') }}</span>
      </div>
      <div class="modal-body">
        {!! Form::open(['route' => 'customer.login.submit', 'id' => 'loginForm', 'data-toggle' => 'validator',
        'novalidate']) !!}
        <!--<div class="form-group">-->
        <!--    <input name="email" id="email" class="form-control input-lg flat" type="email" placeholder="{{ trans('theme.placeholder.your_email') }}" required/>-->
        <!--    <div class="help-block with-errors"></div>-->
        <!--</div>-->
        <div class="form-group">
          <input name="email" id="email" class="form-control input-lg flat" type="text" placeholder="Your Email"
            required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <input name="password" id="password" class="form-control input-lg flat" type="password" minlength="6"
            placeholder="Password Required" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="row">
          <div class="col-xs-7">
            <div class="form-group">
              <label>
                <input name="remeber" id="remeber" class="i-check-blue" type="checkbox" />
                {{ trans('theme.remember_me') }}
              </label>
            </div>
          </div>
          <div class="col-xs-5">
            <input class="btn btn-block btn-lg flat btn-primary" type="submit"
              value="{{ trans('theme.button.login') }}">
          </div>
        </div>
        {!! Form::close() !!}

        <div class="row">
          <a class="btn btn-link" data-dismiss="modal" data-toggle="modal"
            data-target="#passwordResetModal">{{ trans('theme.forgot_password') }}</a>
          <a class="btn btn-link" data-dismiss="modal" data-toggle="modal"
            data-target="#createAccountModal">{{ trans('theme.register_here') }}</a>
        </div>

        <div class="social-auth-links text-center">
          <div class="row">
            <div class="col-md-6 nopadding-right">
              <a href="{{ route('customer.login.social', 'facebook') }}"
                class="btn btn-block btn-social btn-facebook btn-lg flat"><i class="fa fa-facebook"></i>
                {{ trans('theme.button.login_with_fb') }}</a>
            </div>
            <div class="col-md-6 nopadding-left">
              <a href="{{ route('customer.login.social', 'google') }}"
                class="btn btn-block btn-social btn-google btn-lg flat"><i class="fa fa-google"></i>
                {{ trans('theme.button.login_with_g') }}</a>
            </div>
          </div>
        </div>
      </div><!-- /.modal-body -->

      <div class="modal-footer">
        @if(env('APP_DEMO') == TRUE)
        <h4>Demo Login::</h4>
        <p>Username: <strong>customer@demo.com</strong> | Password: <strong>123456</strong> </p>
        @endif
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /#loginModal -->

<div class="modal auth-modal fade" id="createAccountModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content flat">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
        <span class="modal-title">{{ trans('theme.create_account') }}</span>
      </div>
      <div class="modal-body">
        {!! Form::open(['route' => 'customer.register', 'id' => 'registerForm' , 'data-toggle' => 'validator',
        'novalidate']) !!}
        <div class="form-group error" style="color:red;display:none"></div>
        <div class="form-group">
          <input name="name" id="name" class="form-control input-lg flat"
            placeholder="{{ trans('theme.placeholder.full_name') }}" type="text" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <input name="stripe_id" id="mobile_number_r" class="form-control input-lg flat" placeholder="Your Mobile"
            type="tel" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <input name="email" id="email_r" class="form-control input-lg flat"
            placeholder="{{ trans('theme.placeholder.your_email') }}" type="email" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <input name="password" id="pass_r" class="form-control input-lg flat"
            placeholder="{{ trans('theme.placeholder.password') }}" type="password" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <input name="password_confirmation" id="conf_pass" class="form-control input-lg flat"
            placeholder="{{ trans('theme.placeholder.confirm_password') }}" type="password" required />
          <div class="help-block with-errors"></div>
        </div>
        <div class="form-group">
          <label>
            <input name="subscribe" class="i-check-blue" type="checkbox" /> {{ trans('theme.input_label.subscribe') }}
          </label>
        </div>
        <div class="row">
          <div class="col-xs-8">
            <div class="form-group">
              <label>
                <input name="agree" class="i-check-blue" type="checkbox" required />
                {{ trans('theme.input_label.agree') }}
              </label>
              <div class="help-block with-errors"></div>
            </div>
          </div>
          <div class="col-xs-12">
            <button class="btn btn-block btn-lg flat btn-primary" type="button" id="send_otp">Next</button>
            <div class="reg" style="display:none">
                <button class="btn btn-block btn-lg flat btn-primary" type="submit">{{ trans('theme.create_account') }} </button>
            </div>
            
          </div>
        </div>
        {!! Form::close() !!}
        <div class="row otp_form" style="display:none;">
          <div class="col-sm-9">
            <div class="form-group">
              <input name="otp" id="otp" class="form-control input-lg flat" placeholder="Enter OTP" type="text" />
            </div>
          </div>
          <div class="col-sm-3">
            <button class="btn btn-block btn-lg flat btn-primary" type="button" id="check_otp">Submit</button>
          </div>
        </div>
        <div class="row">
          <a class="btn btn-link" data-dismiss="modal" data-toggle="modal"
            data-target="#loginModal">{{ trans('theme.have_account') }}</a>
        </div>

        <div class="social-auth-links text-center">
          <div class="row">
            <div class="col-md-6 nopadding-right">
              <a href="{{ route('customer.login.social', 'facebook') }}"
                class="btn btn-block btn-social btn-facebook btn-lg flat"><i class="fa fa-facebook"></i>
                {{ trans('theme.button.login_with_fb') }}</a>
            </div>
            <div class="col-md-6 nopadding-left">
              <a href="{{ route('customer.login.social', 'google') }}"
                class="btn btn-block btn-social btn-google btn-lg flat"><i class="fa fa-google"></i>
                {{ trans('theme.button.login_with_g') }}</a>
            </div>
          </div>
        </div>
      </div><!-- /.modal-body -->
      <div class="modal-footer"></div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /#createAccountModal -->

<div class="modal auth-modal fade" id="passwordResetModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content flat">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
            aria-hidden="true">&times;</span></button>
        <span class="modal-title">{{ trans('theme.password_recovery') }}</span>
      </div>
      <div class="modal-body">
        {!! Form::open(['route' => 'customer.password.email', 'id' => 'psswordRecoverForm', 'data-toggle' =>
        'validator', 'novalidate']) !!}
        <div class="form-group">
          <input name="email" class="form-control input-lg flat"
            placeholder="{{ trans('theme.placeholder.your_email') }}" type="email" required />
          <div class="help-block with-errors"></div>
        </div>
        <input class="btn btn-block flat btn-primary" type="submit"
          value="{{ trans('theme.button.recover_password') }}" />
        {!! Form::close() !!}
      </div><!-- /.modal-body -->
      <div class="modal-footer"></div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /#passwordResetModal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
  $(document).ready(function () {

    $("#mobile_number").on("keypress keyup blur", function (event) {
      $(this).val($(this).val().replace(/[^\d].+/, ""));
      if ((event.which < 48 || event.which > 57)) {
        event.preventDefault();
      }
    });

    $("#send_otp").on('click', function (e) {
      var name = $("#name").val();
      var mobile = $("#mobile_number_r").val();
      var email = $("#email_r").val();
      var pass = $("#pass_r").val();
      var cpass = $("#conf_pass").val();
      console.log(name + "/n" + mobile + "/n" + email + "/n" + pass + "/n" + cpass);

      if (mobile != "") {
        $.ajax({
          url: '{{ route("customer.otp.send") }}',
          type: 'POST',
          data: {
            mobile: mobile
          },
          complete: function (data) {
            if (data.responseText == "success") {
              $(".otp_form").css("display", "block");
              $("#send_otp").css("display", "none");
            }

          },
        });
      } else {

      }

      if (name == "" || name == undefined) {
        $(".error").css("display", "block");
        $(".error").text("please enter name");
      } else {
        $(".error").css("display", "none");
      }

      if (mobile == "" || mobile == undefined) {
        console.log('hi');
        $(".error").css("display", "block");
        $(".error").text("please enter mobile number");
      } else {
        $(".error").css("display", "none");
      }

      if (email == "" || email == undefined) {
        $(".error").css("display", "block");
        $(".error").text("please enter email");
      } else {
        $(".error").css("display", "none");
      }

      if (pass == "" || pass == undefined) {
        $(".error").css("display", "block");
        $(".error").text("please enter password");
      } else {
        $(".error").css("display", "none");
      }

      if (cpass == "" || cpass == undefined) {
        $(".error").css("display", "block");
        $(".error").text("please enter confirm password");
      } else {
        $(".error").css("display", "none");
      }

      if (pass != cpass) {
        $(".error").css("display", "block");
        $(".error").text("password doesn't matched");
      } else {
        $(".error").css("display", "none");
      }
    //   $(e.target.form).submit();
    });

    $("#check_otp").on('click', function () {
      var otp = $("#otp").val();
      var mobile = $("#mobile_number_r").val();

      if (otp != "" || otp != undefined) {
        $.ajax({
          url: '{{ route('customer.otp.check') }}',
          type: 'POST',
          data: {
            otp: otp,
            mobile: mobile
          },

          complete: function (data) {
            console.log(data.responseText);
            if (data.responseText == "success") {
              $(".otp_form").css("display", "none");
              $(".reg").css("display", "block");
            } else {
              $(".error").css("display", "block");
              $(".error").text("otp is wrong");
              return false;
            }

          },
        });
      } else {

      }
    });
    
  });
</script>