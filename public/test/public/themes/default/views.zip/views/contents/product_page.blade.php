@php
$shipping_country_id = get_id_of_model('countries', 'iso_3166_2', $geoip->iso_code);
$shipping_state_id = $geoip->state;

$shipping_zone = get_shipping_zone_of($item->shop_id, $shipping_country_id, $shipping_state_id);
$shipping_options = isset($shipping_zone->id) ? getShippingRates($shipping_zone->id) : 'NaN';
@endphp

<style>
	tr {
		line-height: 25px;
		min-height: 25px;
		height: 25px;
	}
</style>

<!--<section style="margin-top:30px;margin-bottom: 30px; padding:10px;">-->
<!--	<div class="container">-->
<!--		<div class="row">-->
<!--			<div class="col-md-12 nopadding">-->
<!--				<section class="category-banner-img-wrapper" style="margin-bottom: 10px;">-->
<!--					<div class="container">-->
<!--						<div class="row">-->
<!--							<div class="col-sm-12">-->
<!--								<div class="banner banner-o-hid"-->
<!--									style="background-color: #333;height:200px;background-size: cover; background-image:url( https://multivendor.atithiinfosoft.com/images/placeholders/add.jpg );">-->
<!--								</div>-->
<!--							</div>-->
<!--						</div>-->
<!--					</div>-->
<!--				</section>-->
<!--			</div>-->
<!--		</div>-->
<!--	</div>-->
<!--</section>-->
<section>
	<div class="container">
		<div class="row sc-product-item" id="single-product-wrapper">
			<div class="col-sm-12 col-xs-12">
				<span class="info-label">
					<h3>{{$item->title}}</h3>
				</span>
			</div>
			<div class="col-md-5 col-sm-12">
				@include('layouts.jqzoom', ['item' => $item])
			</div><!-- /.col-md-5 col-sm-6 -->

			<div class="col-md-7 col-sm-12">
				<div class="row" style="margin-top:20px;">
					<!--<div class="col-sm-4 col-xs-12 col-md-4">-->
					<!--    <p>Product Name : Product Name</p>-->
					<!--    <p>Start Rating : <i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;<i class="fa  fa-star" style="color:#f5c004;"></i></p>-->
					<!--    <p>Product Name : Product Name</p>-->
					<!--    <p>Product Name : Product Name</p>-->
					<!--    <p>Product Name : Product Name</p>-->
					<!--    <p>Product Name : Product Name</p>-->
					<!--</div>-->
					<div class="col-sm-12 col-xs-12 col-md-12 table-responsive">

						<table class="table table-striped">
							<thead>
								<tr>
									<th width="25%">Name</th>
									<th width="25%">Price</th>
									<th width="25%">Shop</th>
									<th width="25%">Rating</th>
									<th width="25%">Buy Now</th>
								</tr>
							</thead>
							<tbody>
							    @foreach($final_products as $fp)
								<tr>
									<td>{{ $fp['name'] }} {{ $fp['slug'] }}</td>
									<td>{{ $fp['price'] }} KSh</td>
									<td>{{ $fp['shop'] }}</td>
									<td>
										@if($fp['rating']=="0")
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>
										@elseif($fp['rating']=="1")
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>
										@elseif($fp['rating']=="2")
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>
										@elseif($fp['rating']=="3")
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star"></i>&nbsp;
										<i class="fa  fa-star"></i>
										@elseif($fp['rating']=="4")
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star"></i>
										@elseif($fp['rating']=="5")
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>&nbsp;
										<i class="fa  fa-star" style="color:#f5c004;"></i>
										@endif

									</td>
									<td class="text-left">
										<a class="btn btn-success btn-sm flat space10 sc-add-to-cart"
											href="{{ route('cart.addItem', $fp['slug']) }}">
											<i class="fa fa-shopping-cart"></i> @lang('theme.button.add_to_cart')
										</a>
										<a class="flat" href="{{ route('wishlist.add', $fp['id']) }}">
											<i class="fa fa-heart-o" data-toggle="tooltip"
												title="@lang('theme.button.add_to_wishlist')"></i>
										</a>
									</td>
								</tr>
								@endforeach

								<tr>
									<td colspan="5" class="text-right">
										<a href="{{ route('cart.index') }}" class="btn btn-success flat space10 ">
											Checkout
										</a>


										<form method="POST" action="{{route('countrywise')}}" style="margin-left:2px">
											@csrf
											<button type="submit"
												class="btn btn-success flat">{{ trans('theme.button.continue_shopping') }}</button>
										</form>

									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div class="space20"></div>
			</div>
		</div><!-- /.row -->
	</div><!-- /.container -->
</section>

<div class="clearfix space20"></div>



<div class="clearfix space20"></div>