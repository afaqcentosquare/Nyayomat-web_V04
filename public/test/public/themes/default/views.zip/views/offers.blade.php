@extends('layouts.main')

@section('content')
    <!-- CONTENT SECTION -->
    @include('contents.offer_page')

    <!-- BROWSING ITEMS -->
    @include('sliders.browsing_items')
@endsection