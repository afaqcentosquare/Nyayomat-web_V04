@extends('layouts.main')

@section('content')
    <!-- CONTENT SECTION -->
    @include('contents.categories_page')

    <!-- BROWSING ITEMS -->
    @include('sliders.browsing_items')
@endsection