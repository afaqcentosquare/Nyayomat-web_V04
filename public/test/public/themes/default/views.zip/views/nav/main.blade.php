<style>
  .ui-autocomplete {
    z-index: 9999 !important;
  }
</style>
<div class="container">
  <nav class="navbar navbar-default navbar-main navbar-light navbar-top">
    <div class="row">
      <div class="col-sm-12 col-xs-12 col-md-3">
        <div class="navbar-header">
          <a class="navbar-brand" href="{{ url('/') }}">
            @if(Storage::exists('logo.png') )
            <img src="{{url(Storage::url('logo.png')) }}" alt="SAM SERVE" style="margin-top:10px" />
            @else
            <img src="https://placehold.it/140x60/eee?text={{ get_platform_title() }}" alt="SAM SERVE" />
            @endif
          </a>
        </div>
      </div>
      <div class="col-sm-12 col-xs-12 col-md-6 table-responsive">
        <div style="width: 100%; display: inline-block;">
        @if(Request::segment(1)!="")
          {!! Form::open(['route' => 'inCategoriesSearch', 'method' => 'GET', 'id' => 'search-categories-form', 'class' =>
          'navbar-left navbar-form navbar-search cus-form', 'role' => 'search', 'style' => 'width:500px']) !!}

          <select name="in" class="search-category-select" id="search-category-select">

            <option value="all_categories">{{ trans('theme.all_categories') }}</option>
            @foreach($categories ?? App\Category::get() as $category)
              <option value="{{ $category['slug'] }}" @if(Request::has('in')) {{ Request::get('in') == $category['slug'] ? ' selected' : '' }}
                @endif>{{ $category['name'] }}
              </option>
            @endforeach
          </select>
          <div class="form-group">
            {!! Form::text('search', null, ['class' => 'form-control availableProducts', 'automplete' =>
            'true','placeholder' => trans('theme.main_searchbox_placeholder')]) !!}
          </div>
          <a class="fa fa-search navbar-search-submit"
            onclick="document.getElementById('search-categories-form').submit()"></a>
          {!! Form::close() !!}
          @endif
        </div>
      </div>
      <div class="col-sm-12 col-xs-12 col-md-3">

        <ul class="nav navbar-nav navbar-right navbar-mob-left">
          @if(Request::segment(1)!="")
          <li>
            <a href="{{ route('cart.index') }}">
              <span>{{ trans('theme.your_cart') }}</span>
              <i class="fa fa-shopping-bag"></i>
              <div id="globalCartItemCount" class="badge">{{ cart_item_count() }}</div>
            </a>
          </li>
          @endif

          @auth('customer')
          <li class="dropdown">
            <a href="{{ route('account', 'dashboard') }}" data-toggle="dropdown" role="button" aria-haspopup="true"
              aria-expanded="true">
              <span>{{ trans('theme.hello') . ', ' . Auth::guard('customer')->user()->getName() }}</span>
              {{-- <span style="margin-top:5px">Points: XX</span> --}}
            </a>
            <ul class="dropdown-menu nav-list">
              <!--<li><a href="{{ route('account', 'dashboard') }}"><i class="fa fa-dashboard fa-fw"></i> @lang('theme.nav.dashboard')</a></li>-->
              <li><a href="{{ route('account', 'dashboard') }}"><i class="fa fa-dashboard fa-fw"></i> Overview</a></li>
              <li><a href="{{ route('account', 'orders') }}"><i class="fa fa-shopping-cart fa-fw"></i>
                  @lang('theme.nav.my_orders')</a></li>
              <li><a href="{{ route('account', 'pendingreviews') }}"><i class="fa fa-warning fa-fw"></i> Pending
                  Review</a></li>
              <li><a href="{{ route('account', 'wishlist') }}"><i class="fa fa-heart-o fa-fw"></i>
                  @lang('theme.nav.my_wishlist')</a></li>
              <!--<li><a href="{{ route('account', 'disputes') }}"><i class="fa fa-rocket fa-fw"></i> @lang('theme.nav.refunds_disputes')</a></li>-->
              <!--<li><a href="{{ route('account', 'coupons') }}"><i class="fa fa-tags fa-fw"></i> @lang('theme.nav.my_coupons')</a></li>-->
              {{-- <li><a href="{{ route('account', 'gift_cards') }}"><i class="fa fa-gift fa-fw"></i>
              @lang('theme.nav.gift_cards')</a>
          </li> --}}

          <li class="sep"></li>
          <li><a href="{{ route('account', 'account') }}"><i class="fa fa-user fa-fw"></i>
              @lang('theme.nav.my_account')</a></li>
          <li><a href="{{ route('customer.logout') }}"><i class="fa fa-power-off fa-fw"></i>
              {{ trans('theme.logout') }}</a></li>
        </ul>
        </li>
        @else
        <li>
          <a href="#nav-login-dialog" data-toggle="modal" data-target="#loginModal">
            <span>{{ trans('theme.sing_in') }}</span>
            {{-- <span style="margin-top:5px;font-size:13px;">Points: XX</span> --}}
          </a>
        </li>
        @endauth

        <!-- <div class="navbar-header">
                        <button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target="#main-nav-collapse" area_expanded="false"><span class="sr-only">{{ trans('theme.nav.menu') }}</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
                        </button>
                    </div> -->
        </ul>

      </div>
    </div>
  </nav>
</div>

