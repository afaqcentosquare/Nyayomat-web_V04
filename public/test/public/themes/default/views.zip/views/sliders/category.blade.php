
<div class="owl-carousel product-carousel">
    {{-- @foreach($category as $item) --}}

        <div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/1.jpg') }}" class="img-responsive" alt="LOGO" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    	<div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/2.jpg') }}" class="img-responsive" alt="LOGO" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    	<div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/3.jpg') }}" alt="LOGO" class="img-responsive" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    	<div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/4.jpg') }}" alt="LOGO" class="img-responsive" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    	<div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/5.jpg') }}" alt="LOGO" class="img-responsive" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    	<div class="banner banner-o-hid " >
			<a class="banner-link" href="javascript:void(0)"></a>
			<img src="{{ Storage::url('food/6.jpg') }}" alt="LOGO" class="img-responsive" title="LOGO" style="width: 100%;height: 200px; @media only screen and (max-width: 768px) {height: 86px};"/>
    	</div>
    {{-- @endforeach --}}
</div>